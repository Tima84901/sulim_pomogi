from django.urls import path, re_path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    # path('cats/<int:cat_id>/', views.categories, name='cats_id'),
    # path('cats/<slug:cat_slug>/', views.categories_by_slug, name='cats'),
    # re_path(r'^archive/(?P<year>[0-9]{4})/', views.archive, name='archive'),
    path('about/', views.about, name='about'),
    path('post/<int:post_id>/', views.show_post, name='post'),
    path('addpage/', views.addpage, name='addpage'),
    path('contact/', views.contact, name='contact'),
    path('login/', views.login, name='login'),
]
