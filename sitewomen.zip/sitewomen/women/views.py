from django.http import HttpResponse, HttpResponseNotFound, Http404, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse
from django.template.loader import render_to_string

menu = [
    {'title': "About gay website", 'url_name': 'about'},
    {'title': "add the statua", 'url_name': 'addpage'},
    {'title': "contacts", 'url_name': 'contact'},
    {'title': "login in website", 'url_name': 'login'},
]

lst = [
    {'id':1, 'title': 'zov', 'pub': True},
    {'id':2, 'title': 'axc', 'pub': False}

]

def index(request):
    data = {'title': 'главная старница дон',
            'menu': menu,
            'float': 28.56,
            'posts': lst,
            }
    return render(request, 'women/index.html', context=data)

def show_post(request, post_id):
    return HttpResponse(f"view by id {post_id}")



def about(request):
    azov = {'title': 'о сайте дон', 'menu': menu}
    return render(request, 'women/about.html', azov)

def addpage(request):
    return HttpResponse("Добавление статьи")

def contact(request):
    return HttpResponse("Добавление контакта")

def login(request):
    return HttpResponse("Добавление лгина")


def page_not_found(request, exception):
    return HttpResponseNotFound("<h1>Страница не найдена, it's over</h1>")